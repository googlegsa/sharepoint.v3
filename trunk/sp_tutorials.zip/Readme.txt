SharePointHosting.com Tutorials List Instructions:
 
1.  Download and unzip the the tutorials.zip beta package into a directory of your choice.
2.  Visit your list template gallery on your WSS 3.0 site, upload the tutorials.stp file into the list.
3.  Create a new list using the SharePointHosting's Tutorials - Beta list template
4.  Name the list Tutorials
5.  Add the webpart associated with the list to any webpart zone on your site.
6.  Modify the shared webpart and change the view to Screencast tutorials for the collasped view.
7.  Enjoy.
 
This beta is available for NON-Commercial use only - any resale, repacking or other use is prohibited.

Questions/Comments/Suggestions? Send an e-mail to supportteam@sharepointhosting.com
